# 📘 Integração e Entrega Contínua (IEC)

Repositório das atividades da disciplina **Integração e Entrega Contínua (IEC)** – DSM.

## 📂 Estrutura
- [Atividade-1](./Atividade-1) → Configuração inicial do repositório, primeiro commit e CI básico.
- [Atividade-2](./Atividade-2) → Fluxo de versionamento avançado (branches, PRs e hotfix).
- [Atividade-3](./Atividade-3) → GitHub Actions com workflow automatizado e triggers para PR.

## 🚀 Objetivos da Disciplina
- Aplicar práticas modernas de **CI/CD**.
- Utilizar **Git e GitHub** de forma colaborativa e profissional.
- Garantir qualidade e rastreabilidade do código em equipe.
