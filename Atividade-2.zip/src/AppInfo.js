const NOME_APP = "Monitor Climático INPE";
