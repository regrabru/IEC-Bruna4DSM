console.log("Aplicativo de Monitoramento de Eventos Climáticos - INPE");
