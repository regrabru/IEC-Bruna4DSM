# Aplicativo INPE – Monitoramento de Eventos Climáticos

Objetivo: App móvel para alertas de queimadas, inundações, desmatamento e relatos da população em tempo real.

## Estrutura inicial
- Repositório privado no GitHub (`inpe-alertas`)
- Branch principal protegida (`main`)
- Branch de desenvolvimento (`dev`)
- Colaboradores adicionados ao projeto
- Pipeline de integração contínua configurado
